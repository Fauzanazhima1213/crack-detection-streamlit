import streamlit as st
import tensorflow as tf
from PIL import Image
import numpy as np

st.set_page_config(
    page_title="AI Deteksi Keretakan",
    page_icon="🧱",
    layout="centered"
)

st.title("🧱 AI Deteksi Keretakan")
st.write("Upload gambar permukaan beton/dinding/jalan. Model akan memprediksi apakah gambar tersebut retak atau tidak retak.")

MODEL_PATH = "crack_detection_model.h5"
IMG_SIZE = (128, 128)

@st.cache_resource
def load_model():
    return tf.keras.models.load_model(MODEL_PATH)

model = load_model()

uploaded_file = st.file_uploader(
    "Upload gambar",
    type=["jpg", "jpeg", "png"]
)

def preprocess_image(image):
    image = image.convert("RGB")
    image = image.resize(IMG_SIZE)
    img_array = np.array(image)
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

if uploaded_file is not None:
    image = Image.open(uploaded_file)

    st.subheader("Gambar yang diupload")
    st.image(image, use_container_width=True)

    img_array = preprocess_image(image)

    prediction = model.predict(img_array)[0][0]

    # Karena waktu training:
    # Negative = 0
    # Positive = 1
    crack_probability = float(prediction)
    no_crack_probability = 1 - crack_probability

    st.subheader("Hasil Prediksi")

    if crack_probability >= 0.5:
        st.error("TERDETEKSI RETAK")
        st.write(f"Tingkat keyakinan retak: **{crack_probability * 100:.2f}%**")
    else:
        st.success("TIDAK TERDETEKSI RETAK")
        st.write(f"Tingkat keyakinan tidak retak: **{no_crack_probability * 100:.2f}%**")

    st.progress(crack_probability)
    st.caption("Catatan: aplikasi ini adalah klasifikasi gambar, jadi hasilnya hanya Retak / Tidak Retak, bukan menandai posisi retakan.")
else:
    st.info("Silakan upload gambar terlebih dahulu.")
