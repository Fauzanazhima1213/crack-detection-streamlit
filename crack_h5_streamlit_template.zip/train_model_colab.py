# ============================================================
# TRAINING MODEL AI DETEKSI KERETAKAN - OUTPUT .H5
# Cocok dijalankan di Google Colab
# Dataset: Kaggle Surface Crack Detection
# Output akhir: crack_detection_model.h5
# ============================================================

# 1. Install library
!pip install kaggle tensorflow matplotlib scikit-learn

# 2. Upload kaggle.json
# Ambil dari Kaggle:
# Account > Settings > API > Create New Token
from google.colab import files
files.upload()  # upload kaggle.json

# 3. Setup Kaggle API
!mkdir -p ~/.kaggle
!cp kaggle.json ~/.kaggle/
!chmod 600 ~/.kaggle/kaggle.json

# 4. Download dataset
!kaggle datasets download -d arunrk7/surface-crack-detection
!unzip -q surface-crack-detection.zip -d /content/crack_dataset

# 5. Cek struktur folder dataset
import os

for root, dirs, files_ in os.walk("/content/crack_dataset"):
    level = root.replace("/content/crack_dataset", "").count(os.sep)
    indent = " " * 2 * level
    print(f"{indent}{os.path.basename(root)}/")
    if level >= 2:
        dirs[:] = []

# 6. Import library
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import matplotlib.pyplot as plt
import numpy as np

# 7. Cari folder yang berisi Positive dan Negative
def find_dataset_root(base_path):
    for root, dirs, files in os.walk(base_path):
        lower_dirs = [d.lower() for d in dirs]
        if "positive" in lower_dirs and "negative" in lower_dirs:
            return root
    raise FileNotFoundError("Folder Positive dan Negative tidak ditemukan.")

DATASET_DIR = find_dataset_root("/content/crack_dataset")
print("Dataset directory:", DATASET_DIR)
print("Isi folder:", os.listdir(DATASET_DIR))

# 8. Parameter
IMG_SIZE = (128, 128)
BATCH_SIZE = 32
SEED = 42

# 9. Load dataset train dan validation
train_ds = tf.keras.utils.image_dataset_from_directory(
    DATASET_DIR,
    labels="inferred",
    label_mode="binary",
    class_names=["Negative", "Positive"],
    validation_split=0.2,
    subset="training",
    seed=SEED,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE
)

val_ds = tf.keras.utils.image_dataset_from_directory(
    DATASET_DIR,
    labels="inferred",
    label_mode="binary",
    class_names=["Negative", "Positive"],
    validation_split=0.2,
    subset="validation",
    seed=SEED,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE
)

print("Class names:", train_ds.class_names)
# Negative = 0
# Positive = 1

# 10. Optimasi pipeline dataset
AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

# 11. Arsitektur CNN sederhana
model = models.Sequential([
    layers.Rescaling(1./255, input_shape=(128, 128, 3)),

    layers.Conv2D(32, (3, 3), activation="relu"),
    layers.MaxPooling2D(),

    layers.Conv2D(64, (3, 3), activation="relu"),
    layers.MaxPooling2D(),

    layers.Conv2D(128, (3, 3), activation="relu"),
    layers.MaxPooling2D(),

    layers.Conv2D(128, (3, 3), activation="relu"),
    layers.MaxPooling2D(),

    layers.Flatten(),
    layers.Dense(128, activation="relu"),
    layers.Dropout(0.4),
    layers.Dense(1, activation="sigmoid")
])

model.compile(
    optimizer="adam",
    loss="binary_crossentropy",
    metrics=["accuracy"]
)

model.summary()

# 12. Callback
callbacks = [
    EarlyStopping(
        monitor="val_loss",
        patience=5,
        restore_best_weights=True
    ),
    ModelCheckpoint(
        "best_crack_model.h5",
        monitor="val_accuracy",
        save_best_only=True,
        mode="max"
    )
]

# 13. Training
history = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=20,
    callbacks=callbacks
)

# 14. Evaluasi
loss, acc = model.evaluate(val_ds)
print(f"Validation Accuracy: {acc:.4f}")
print(f"Validation Loss: {loss:.4f}")

# 15. Grafik training
plt.figure(figsize=(8, 5))
plt.plot(history.history["accuracy"], label="Training Accuracy")
plt.plot(history.history["val_accuracy"], label="Validation Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.title("Training vs Validation Accuracy")
plt.show()

plt.figure(figsize=(8, 5))
plt.plot(history.history["loss"], label="Training Loss")
plt.plot(history.history["val_loss"], label="Validation Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.title("Training vs Validation Loss")
plt.show()

# 16. Simpan model final ke .h5
model.save("crack_detection_model.h5")

# 17. Download model .h5 ke laptop
from google.colab import files
files.download("crack_detection_model.h5")
