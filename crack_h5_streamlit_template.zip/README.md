# AI Deteksi Keretakan - H5 + Streamlit

Project ini memakai model CNN klasifikasi 2 kelas:

- Negative = Tidak Retak
- Positive = Retak

## Isi File

- `train_model_colab.py` = kode training untuk Google Colab
- `app.py` = aplikasi web Streamlit
- `requirements.txt` = library yang dibutuhkan
- `README.md` = panduan singkat

## Alur

1. Jalankan kode `train_model_colab.py` di Google Colab.
2. Download file hasil training: `crack_detection_model.h5`.
3. Letakkan file `crack_detection_model.h5` satu folder dengan `app.py`.
4. Jalankan aplikasi:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Struktur Folder Streamlit

```text
crack_app/
├── app.py
├── crack_detection_model.h5
└── requirements.txt
```

## Output Aplikasi

Upload gambar -> AI menjawab:

- TERDETEKSI RETAK
- TIDAK TERDETEKSI RETAK

Beserta persentase keyakinan model.
